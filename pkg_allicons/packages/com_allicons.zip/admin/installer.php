<?php

defined('_JEXEC') or die('Restricted Access');

class Com_AllIconsInstallerScript
{
    
    function install($parent)
    {
        
    }
    
    function uninstall($parent)
    {
        
        
    }
    
    function update($parent)
    {
        
        
    }
    
    function preflight($type, $parent)  
    {
        
        
    }
    
    function postflight($type, $parent)
    {
        
        
    }
}
